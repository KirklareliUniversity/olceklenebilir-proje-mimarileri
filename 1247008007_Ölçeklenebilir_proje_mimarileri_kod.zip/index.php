﻿<?php
require_once __DIR__ . "/auth.php";
require_login();

$user = current_user();
include __DIR__ . "/header.php";
?>

<!-- Hero Section -->
<section class="hero">
    <div class="container">
        <div class="hero-content">
            <div class="hero-text">
                <div class="hero-badge">
                    <span class="badge-dot"></span>
                    Mobil Programlama Projesi
                </div>
                <h1 class="hero-title">Flutter'da Clean Architecture ve Test-Driven Development</h1>
                <p class="hero-description">
                    Ölçeklenebilir, test edilebilir ve sürdürülebilir mobil uygulamalar geliştirmek için 
                    modern mimari yaklaşımlar ve en iyi pratikler.
                </p>
                <div class="hero-actions">
                    <a href="#architecture" class="btn btn-primary btn-lg">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10"></circle>
                            <polygon points="10 8 16 12 10 16 10 8"></polygon>
                        </svg>
                        Keşfet
                    </a>
                    <a href="#about" class="btn btn-secondary btn-lg">Daha Fazla Bilgi</a>
                </div>
            </div>
            <div class="hero-visual">
                <div class="code-window">
                    <div class="code-header">
                        <span class="dot red"></span>
                        <span class="dot yellow"></span>
                        <span class="dot green"></span>
                        <span class="code-title">lib/src/domain/user.dart</span>
                    </div>
                    <pre class="code-body"><code><span class="keyword">class</span> <span class="class">User</span> {
  <span class="keyword">final</span> <span class="type">int</span> id;
  <span class="keyword">final</span> <span class="type">String</span> name;
  <span class="keyword">final</span> <span class="type">String</span> email;

  <span class="class">User</span>({
    <span class="keyword">required</span> <span class="keyword">this</span>.id,
    <span class="keyword">required</span> <span class="keyword">this</span>.name,
    <span class="keyword">required</span> <span class="keyword">this</span>.email,
  });
}</code></pre>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Stats Section -->
<section class="stats-section">
    <div class="container">
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon blue">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polygon points="12 2 2 7 12 12 22 7 12 2"></polygon>
                        <polyline points="2 17 12 22 22 17"></polyline>
                        <polyline points="2 12 12 17 22 12"></polyline>
                    </svg>
                </div>
                <div class="stat-info">
                    <span class="stat-number">3</span>
                    <span class="stat-label">Mimari Katman</span>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon green">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                        <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    </svg>
                </div>
                <div class="stat-info">
                    <span class="stat-number">TDD</span>
                    <span class="stat-label">Test-First Yaklaşım</span>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon purple">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                        <line x1="3" y1="9" x2="21" y2="9"></line>
                        <line x1="9" y1="21" x2="9" y2="9"></line>
                    </svg>
                </div>
                <div class="stat-info">
                    <span class="stat-number">Flutter</span>
                    <span class="stat-label">Cross-Platform</span>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon orange">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                    </svg>
                </div>
                <div class="stat-info">
                    <span class="stat-number"><?= htmlspecialchars($user['name']) ?></span>
                    <span class="stat-label">Hoş Geldin!</span>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Architecture Section -->
<section id="architecture" class="content-section">
    <div class="container">
        <div class="section-header">
            <span class="section-badge">Mimari Yapı</span>
            <h2 class="section-title">Clean Architecture Katmanları</h2>
            <p class="section-desc">Robert C. Martin'ın Clean Architecture prensiplerinin Flutter'a uyarlanmış hali</p>
        </div>
        
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon domain">
                    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <circle cx="12" cy="12" r="4"></circle>
                    </svg>
                </div>
                <h3>Domain Layer</h3>
                <p>İş kurallarının saf haliyle yer aldığı merkez katman. Entities ve Use Cases burada tanımlanır.</p>
                <ul class="feature-list">
                    <li>Entities (User, Product...)</li>
                    <li>Use Cases (GetUser, CreateOrder...)</li>
                    <li>Repository Interfaces</li>
                </ul>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon data">
                    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <ellipse cx="12" cy="5" rx="9" ry="3"></ellipse>
                        <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"></path>
                        <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"></path>
                    </svg>
                </div>
                <h3>Data Layer</h3>
                <p>Veri kaynaklarıyla iletişimi sağlayan katman. API, veritabanı ve cache işlemleri burada yapılır.</p>
                <ul class="feature-list">
                    <li>Models (JSON Serialization)</li>
                    <li>Repository Implementations</li>
                    <li>Remote/Local Data Sources</li>
                </ul>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon presentation">
                    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                        <line x1="8" y1="21" x2="16" y2="21"></line>
                        <line x1="12" y1="17" x2="12" y2="21"></line>
                    </svg>
                </div>
                <h3>Presentation Layer</h3>
                <p>Kullanıcı arayüzü ve state management. Widget'lar ve Cubit/BLoC yapıları burada bulunur.</p>
                <ul class="feature-list">
                    <li>Screens & Widgets</li>
                    <li>Cubit / BLoC</li>
                    <li>State Management</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<!-- TDD Section -->
<section id="tdd" class="content-section alt-bg">
    <div class="container">
        <div class="section-header">
            <span class="section-badge green">Test-Driven Development</span>
            <h2 class="section-title">Red  Green  Refactor</h2>
            <p class="section-desc">Önce test yaz, sonra kodu geliştir, en son temizle</p>
        </div>
        
        <div class="tdd-grid">
            <div class="tdd-step">
                <div class="step-number red">1</div>
                <div class="step-content">
                    <h4>Red</h4>
                    <p>Başarısız olacak bir test yaz. Test henüz geçmeyecek çünkü kod yazılmadı.</p>
                </div>
            </div>
            <div class="tdd-arrow"></div>
            <div class="tdd-step">
                <div class="step-number green">2</div>
                <div class="step-content">
                    <h4>Green</h4>
                    <p>Testi geçirecek en basit kodu yaz. Mükemmel olması gerekmiyor, sadece çalışsın.</p>
                </div>
            </div>
            <div class="tdd-arrow"></div>
            <div class="tdd-step">
                <div class="step-number blue">3</div>
                <div class="step-content">
                    <h4>Refactor</h4>
                    <p>Kodu temizle, iyileştir. Testler hala geçiyor olmalı.</p>
                </div>
            </div>
        </div>
        
        <div class="test-types">
            <div class="test-card">
                <h5>Unit Tests</h5>
                <p>Tek bir fonksiyon veya use case mantığının test edilmesi</p>
            </div>
            <div class="test-card">
                <h5>Widget Tests</h5>
                <p>UI bileşenlerinin davranışının test edilmesi</p>
            </div>
            <div class="test-card">
                <h5>Integration Tests</h5>
                <p>Uygulamanın uçtan uca test edilmesi</p>
            </div>
        </div>
    </div>
</section>

<!-- Project Structure Section -->
<section class="content-section">
    <div class="container">
        <div class="section-header">
            <span class="section-badge purple">Proje Yapısı</span>
            <h2 class="section-title">Örnek Flutter Uygulaması</h2>
            <p class="section-desc">Kullanıcı ID'si ile API sorgulama senaryosu</p>
        </div>
        
        <div class="project-layout">
            <div class="folder-tree">
                <div class="tree-header">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
                    </svg>
                    lib/src/
                </div>
                <div class="tree-content">
                    <div class="tree-folder">
                        <span class="folder-name domain"> domain/</span>
                        <div class="folder-files">
                            <span> entities/user.dart</span>
                            <span> repositories/user_repository.dart</span>
                            <span> usecases/get_user.dart</span>
                        </div>
                    </div>
                    <div class="tree-folder">
                        <span class="folder-name data"> data/</span>
                        <div class="folder-files">
                            <span> models/user_model.dart</span>
                            <span> repositories/user_repository_impl.dart</span>
                            <span> datasources/remote_data_source.dart</span>
                        </div>
                    </div>
                    <div class="tree-folder">
                        <span class="folder-name presentation"> presentation/</span>
                        <div class="folder-files">
                            <span> cubit/user_cubit.dart</span>
                            <span> screens/home_screen.dart</span>
                            <span> widgets/user_card.dart</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="project-info">
                <h4>Uygulama Özellikleri</h4>
                <ul>
                    <li>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                        ID ile kullanıcı sorgulama
                    </li>
                    <li>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                        REST API entegrasyonu
                    </li>
                    <li>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                        Loading, Loaded, Error states
                    </li>
                    <li>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                        Dependency Injection (get_it)
                    </li>
                    <li>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                        Unit ve Widget testleri
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>

<!-- About Section -->
<section id="about" class="content-section alt-bg">
    <div class="container">
        <div class="section-header">
            <span class="section-badge orange">Hakkında</span>
            <h2 class="section-title">Proje ve Hazırlayan</h2>
        </div>
        
        <div class="about-grid">
            <div class="about-card">
                <h4> Çalışma Bilgileri</h4>
                <table class="info-table">
                    <tr><td>Üniversite</td><td>T.C. Kırklareli Üniversitesi</td></tr>
                    <tr><td>Fakülte</td><td>Teknik Bilimler MYO</td></tr>
                    <tr><td>Bölüm</td><td>Bilgisayar Teknolojileri</td></tr>
                    <tr><td>Program</td><td>Bilgisayar Programcılığı</td></tr>
                    <tr><td>Ders</td><td>Mobil Programlama</td></tr>
                    <tr><td>Dönem</td><td>2025-2026 Güz</td></tr>
                </table>
            </div>
            
            <div class="about-card">
                <h4>👩‍💻 Hazırlayan</h4>
                <div class="student-info">
                    <img src="profile.jpg" alt="Eylül Kay" class="student-avatar-img">
                    <div class="student-details">
                        <h5>Eylül Kay</h5>
                        <p>1247008007</p>
                    </div>
                </div>
                <div class="instructor-info">
                    <span class="label">Öğretim Elemanı</span>
                    <span class="value">Nadir Subaşı</span>
                </div>
                <div class="date-info">
                    <span class="label">Tarih / Yer</span>
                    <span class="value">Kırklareli, Aralık 2025</span>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include __DIR__ . "/footer.php"; ?>