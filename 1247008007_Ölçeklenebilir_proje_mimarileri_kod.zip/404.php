<?php include __DIR__ . "/header.php"; ?>
<div class="section-card">
    <h1 class="section-title">404 – Sayfa Bulunamadı</h1>
    <div class="section-body">
        <p>Aradığınız sayfa bulunamadı. Ana sayfaya dönmek için <a href="index.php">buraya tıklayın</a>.</p>
    </div>
</div>
<?php include __DIR__ . "/footer.php"; ?>
