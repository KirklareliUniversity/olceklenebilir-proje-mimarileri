﻿    </main>
    
    <!-- Footer -->
    <footer class="site-footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-brand">
                    <a href="index.php" class="logo">
                        <span class="logo-icon">
                            <svg width="32" height="32" viewBox="0 0 100 100" fill="none">
                                <rect width="100" height="100" rx="20" fill="white"/>
                                <path d="M30 70V30l20 20 20-20v40" stroke="#1a1c1d" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </span>
                        <span>Clean Architecture</span>
                    </a>
                    <p class="footer-desc">
                        Flutter ile modern mimari yaklaşımlar ve test-driven development üzerine hazırlanmış akademik proje.
                    </p>
                </div>
                
                <div class="footer-links">
                    <h4>Hızlı Linkler</h4>
                    <ul>
                        <li><a href="#architecture">Mimari Yapı</a></li>
                        <li><a href="#tdd">TDD Yaklaşımı</a></li>
                        <li><a href="#about">Hakkında</a></li>
                    </ul>
                </div>
                
                <div class="footer-links">
                    <h4>Proje Bilgileri</h4>
                    <ul>
                        <li><a href="#">Clean Architecture</a></li>
                        <li><a href="#">Test-Driven Dev</a></li>
                        <li><a href="#">Flutter & Dart</a></li>
                    </ul>
                </div>
                
                <div class="footer-links">
                    <h4>İletişim</h4>
                    <ul>
                        <li><a href="#">Eylül Kay</a></li>
                        <li><a href="#">1247008007</a></li>
                        <li><a href="#">Kırklareli Üniversitesi</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; 2025 Clean Architecture Projesi. Tüm hakları saklıdır.</p>
                <p class="footer-credit">
                    Hazırlayan: <a href="#">Eylül Kay</a> | Ders: Mobil Programlama
                </p>
            </div>
        </div>
    </footer>
</body>
</html>