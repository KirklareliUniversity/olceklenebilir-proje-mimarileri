﻿<?php
$user = current_user();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clean Architecture & TDD | Flutter Projesi</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Announcement Bar -->
    <div class="announcement-bar">
        <div class="container">
            <span> Kırklareli Üniversitesi - Mobil Programlama Dersi Projesi</span>
        </div>
    </div>
    
    <!-- Header -->
    <header class="site-header">
        <div class="container">
            <div class="header-inner">
                <a href="index.php" class="logo">
                    <span class="logo-icon">
                        <svg width="32" height="32" viewBox="0 0 100 100" fill="none">
                            <rect width="100" height="100" rx="20" fill="#008060"/>
                            <path d="M30 70V30l20 20 20-20v40" stroke="white" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </span>
                    <span>Clean Architecture</span>
                </a>
                
                <nav class="nav-main">
                    <a href="#architecture" class="nav-link">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polygon points="12 2 2 7 12 12 22 7 12 2"></polygon>
                            <polyline points="2 17 12 22 22 17"></polyline>
                            <polyline points="2 12 12 17 22 12"></polyline>
                        </svg>
                        Mimari
                    </a>
                    <a href="#tdd" class="nav-link">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                            <polyline points="22 4 12 14.01 9 11.01"></polyline>
                        </svg>
                        TDD
                    </a>
                    <a href="#about" class="nav-link">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10"></circle>
                            <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
                            <line x1="12" y1="17" x2="12.01" y2="17"></line>
                        </svg>
                        Hakkında
                    </a>
                </nav>
                
                <div class="nav-actions">
                    <?php if ($user): ?>
                        <a href="#" class="user-menu">
                            <span class="user-avatar"><?= strtoupper(substr($user['name'], 0, 1)) ?></span>
                            <span class="user-name"><?= htmlspecialchars($user['name']) ?></span>
                        </a>
                        <a href="logout.php" class="btn btn-secondary">Çıkış</a>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-secondary">Giriş</a>
                        <a href="register.php" class="btn btn-primary">Kayıt Ol</a>
                    <?php endif; ?>
                </div>
                
                <button class="mobile-menu-btn">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="3" y1="12" x2="21" y2="12"></line>
                        <line x1="3" y1="6" x2="21" y2="6"></line>
                        <line x1="3" y1="18" x2="21" y2="18"></line>
                    </svg>
                </button>
            </div>
        </div>
    </header>
    
    <main>