<?php
// config.php
$DB_HOST = "localhost";
$DB_NAME = "flutter_presentation";
$DB_USER = "root";      // XAMPP varsayılan
$DB_PASS = "";          // şifren varsa buraya yaz
$APP_NAME = "Flutter Proje Sunumu";
?>
