<?php
// auth.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . "/db.php";

function current_user()
{
    if (!isset($_SESSION['user_id'])) {
        return null;
    }

    global $pdo;
    $stmt = $pdo->prepare("SELECT id, name, email, created_at FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch() ?: null;
}

function require_login()
{
    if (!current_user()) {
        header("Location: login.php");
        exit;
    }
}

function find_user_by_email(string $email)
{
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    return $stmt->fetch();
}

function create_user(string $name, string $email, string $password, &$error = null)
{
    global $pdo;

    if (find_user_by_email($email)) {
        $error = "Bu e-posta adresi zaten kayıtlı.";
        return false;
    }

    $hash = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $pdo->prepare(
        "INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)"
    );

    try {
        $stmt->execute([$name, $email, $hash]);
        return $pdo->lastInsertId();
    } catch (PDOException $e) {
        $error = "Kayıt sırasında bir hata oluştu.";
        return false;
    }
}

function login_user(string $email, string $password, &$error = null)
{
    $user = find_user_by_email($email);
    if (!$user) {
        $error = "E-posta veya şifre hatalı.";
        return false;
    }

    if (!password_verify($password, $user['password_hash'])) {
        $error = "E-posta veya şifre hatalı.";
        return false;
    }

    $_SESSION['user_id'] = $user['id'];
    return true;
}

function logout_user()
{
    $_SESSION = [];
    session_destroy();
    header("Location: login.php");
    exit;
}
